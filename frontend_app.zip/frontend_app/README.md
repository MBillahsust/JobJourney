
  # MVP Feature Design Screens

  This is a code bundle for MVP Feature Design Screens. The original project is available at https://www.figma.com/design/XliciynXpwH7QgRJd2rgdI/MVP-Feature-Design-Screens.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  